import numpy as np
from scipy import signal
from matplotlib import pyplot as plt
import imageio.v2 as imageio


# # # # # #  Do not touch this 

def Energy(u,D,lmbda):
    fAu = np.sum(np.sqrt(A(u)[0]**2 + A(u)[1]**2))
    gu = lmbda/2*np.sum( (u-D)**2)
    return fAu+ gu
                    
def add_noise(u, noise_lvl, noise_type):
    if noise_type == "uniform":
        noise = np.random.rand(*u.shape)*np.max(u)*noise_lvl
        return u + noise 
    elif noise_type == "saltpepper":
        u = u + 0 # taking a copy of u
        M = round(u.size*noise_lvl)
        minn = np.min(u)
        maxx = np.max(u)
        for i in range(M):
            coord_x = np.random.randint(0,u.shape[0])
            coord_y = np.random.randint(0,u.shape[1])
            selection = np.random.randint(0,2)
            u[coord_x, coord_y] = minn*selection + maxx*(1-selection)
        return u
    else:
        print("Not a valid noise type in the add_noise function")


def plot_result(img, D, u, energy):
    fig, ax = plt.subplots(nrows=2, ncols=2)
    ax[0,0].imshow(img, cmap='gray')
    ax[0,0].set_title("Original image")
    ax[0,0].set_xticks([])
    ax[0,0].set_yticks([])
    ax[0,1].imshow(D, cmap='gray')
    ax[0,1].set_title("Noisy image")
    ax[0,1].set_xticks([])
    ax[0,1].set_yticks([])
    ax[1,0].imshow(u, cmap='gray')
    ax[1,0].set_title("regularized image")
    ax[1,0].set_xticks([])
    ax[1,0].set_yticks([])
    ax[1,1].plot(energy[2:])
    ax[1,1].set_title("Energy of solution per iteration")
    return fig

# # # # # #

# # b)
def A(u):
    # Write function, make it return a tuple of np.array's
    return (ux, uy)
    
def A_star(p):
    # # Write this function, 
    
# # d)
def resolvent_f_star(p):
    # # Write this function

# # g)
def resolvent_g(u, D,tau, lmbda):
    # # Write this function
    
    
def primal_dual(tau, sigma, theta, lmbda, x0, y0, D, A, A_star,
                resolvent_f_star, resolvent_g, num_iter):
    x_bar = x0
    y = y0
    x = x0
    energy = np.zeros(num_iter)
    for i in range(num_iter):
        # # Write this part
        energy[i] = Energy(xp, D, lmbda)
    return xp, energy


# # # # # Main simulations

# load image
cameraman = imageio.imread('cameraman.tif')
# Initial values
N = cameraman.shape[1]
x0 = np.zeros((N,N))
y0 = (np.zeros((N,N)), np.zeros((N,N)))
# iteration parameters
sigma = 1/2
tau = 1/2
theta = 1

# #  Case with uniform noise
# regularization parameter
lmbda = 0.05
# noisy image
noise_lvl = 0.4
D = add_noise(cameraman,noise_lvl, "uniform")
# regularized image
num_iter = 100
u, energy = primal_dual(tau,sigma,theta, lmbda, x0,y0,D, A, A_star, 
                 resolvent_f_star, resolvent_g, num_iter)

fig = plot_result(cameraman, D, u, energy)
fig.suptitle("Uniform noise example")
plt.savefig("uniform_noise.pdf")
plt.show()

# # Case with saltpepper noise
# regularization parameter
lmbda = 0.01
# noisy image
noise_lvl = 0.3
D = add_noise(cameraman,noise_lvl, "saltpepper")
# regularized image
num_iter = 400
u, energy = primal_dual(tau,sigma,theta, lmbda, x0,y0,D, A, A_star, 
                 resolvent_f_star, resolvent_g, num_iter)

fig = plot_result(cameraman, D, u, energy)
fig.suptitle("Salpepper noise example")
plt.savefig("saltpepper_noise.pdf")
plt.show()

