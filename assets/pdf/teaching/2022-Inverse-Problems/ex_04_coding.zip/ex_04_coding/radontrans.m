function RT = radontrans(Img, thetas)
% Radon transform
% Input:
%   Img: Square matrix
%   thetas: Vector of angles, in degrees (not radians)
%
% Output:
%   RT: size(Img,1) x length(thetas) matrix.


% The input value Img represents a function defined on [-1,1]x[-1,1], whose 
% support is restricted to the unit ball.


if(size(Img,1)~=size(Img,2))
    error('The input image must be square')
end

N = size(Img,1);
RT = zeros(N, length(thetas));

% % Write here your implementation of the Radon transform. % %