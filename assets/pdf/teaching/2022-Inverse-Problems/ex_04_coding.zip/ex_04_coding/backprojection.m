function RS = backprojection(RT, thetas)
% Adjoint of the Radon transform, or backprojection operator.
% Input:
%   RT: N x length(thetas) matrix.
%   thetas: Vector of angles (in degrees, not radians)
%
% Output:
%   RS: NxN matrix.

if length(thetas)~=size(RT,2)
    error(['there must be the same number of given angles as the dimension'...
        ' 2 of the input sinogram']);
end
N = size(RT,1);
RS = zeros(N,N);

% % Write here your implementation of the backprojection operator % % 