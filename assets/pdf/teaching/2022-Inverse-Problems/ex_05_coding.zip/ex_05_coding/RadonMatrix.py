import numpy as np
from scipy.sparse import lil_matrix
from matplotlib import pyplot as plt


def RadonMatrix(N, T, max_t, S):
# N is such that we consider images of size NxN
# T is the total number of considered angles for imaging.
# max_t is the maximum range of considered angles. The code
#   should uniformly sample the angles in [0, max_theta].
# S is the total number of uniform samples of the s variable, 
#   between [-1,1].

    R = lil_matrix((T*S, N*N))
    ## Here goes your code ##
    return R


# # # Section to check if your implementation is correct. # # #

def image_to_vector(Img):
    ## Write here your transformation ##
	
def vector_to_image(vect,T,S):
    ## Write here your transformation ##

def imshow(Img):
    plt.imshow(Img, interpolation="nearest")
    plt.show()

def draw_dot(N,x0,r):
    Img = np.zeros([N,N])
    xgrid = np.linspace(-1,1,N+1)
    dx = xgrid[1]-xgrid[0]
    xgrid = xgrid[:-1]+dx/2
    ygrid = np.linspace(1,-1,N+1)
    dy = ygrid[1]-ygrid[0]
    ygrid = ygrid[:-1]+dy/2
    for j in range(N):
        for i in range(N):
            if (xgrid[j]-x0[0])**2+(ygrid[i]-x0[1])**2 <= r**2:
                Img[i,j]=1
    return Img

N = 40;
T = 60;
S = 40;
max_t = 2*pi;
Img = draw_dot(N, [0,0.3], 0.2)
R = RadonMatrix(N,T, max_t, S)
imshow(Img)

sinogram = R*image_to_vector(Img)
imshow(sinogram)


