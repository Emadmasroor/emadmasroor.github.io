import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import lsqr
from matplotlib import pyplot as plt

from RadonMatrix.py import RadonMatrix, draw_dot, imshow, image_to_vector, vector_to_image

def Add_noise(vector, noise_level):
    return vector + np.random.rand(len(vector))*np.max(vector)*noise_level


# Fixed parameters
N = 40
T = 60
S = 40
Img = draw_dot(N, [0,0.3], 0.2)  #imshow(Img)

# Flexible parameteres
max_t = 2*np.pi
noise_level = 0.05

# Inversion process
#   Use from scipy.spare.linalg the lsqr method for inverting, add noise with the provided method.


